# Yomu — Manga Reader

A responsive manga-reader starter built with HTML, CSS, JavaScript, Vite and Capacitor. It includes a MangaDex catalog adapter, local library, chapter reader, IndexedDB chapter downloads,.

## Included features
- MangaDex title search and popular catalog discovery
- Manga details and English chapter list
- Library and reading history stored locally
- Reader view with page navigation/scrolling
- Download chapter pages into IndexedDB for offline reading
- Dark/light theme, reader direction/page-fit preferences, JSON backup export
- Capacitor Android wrapper and GitHub Actions debug APK workflow
- Responsive mobile and desktop layouts

Yomu uses MangaDex as its only catalog and chapter source.

## Run locally
Install Node.js 20+.

```bash
npm install
npm run start
```
Open the Vite URL printed in your terminal (usually `http://localhost:5173`).

## Build web version
```bash
npm run build
```
The source files live in `www/`; Vite uses `www/` as its root and generates the static site in `dist/`.

## Build Android APK locally
Requirements: Android Studio, Android SDK, JDK 21, and Node.js 20+.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is usually at `android/app/build/outputs/apk/debug/app-debug.apk`.

For later web changes:
```bash
npm run build
npx cap sync android
```

## Push to GitHub
1. Create a new empty repository on GitHub, e.g. `yomu-manga-reader`.
2. Extract this ZIP.
3. Open a terminal in the extracted `yomu-manga-reader` folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial Yomu manga reader"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/yomu-manga-reader.git
git push -u origin main
```

5. On GitHub, open **Actions** and run **Build Android APK** (or push to `main` to trigger it).
6. Open the completed workflow run → Artifacts → download `yomu-debug-apk`.

## GitHub Pages (optional)
This project uses Vite. To host it on GitHub Pages, set the Vite `base` to your repository path in `vite.config.js` or configure a custom domain, then deploy the `dist/` folder. The API and offline storage need a browser with network access on first use.

## Notes
- MangaDex API and cover/page servers are third-party services. Availability, CORS, rate limits and content rules can change.
- Download only content you are authorized to access and keep offline.
- Browser storage can be cleared by the OS/browser; export backups regularly.
- The app is a starter implementation, not a native Mihon fork. Native Android extension execution, trackers, cloud sync, source migration, scheduled updates and advanced fork-specific features are not implemented in this web build.
