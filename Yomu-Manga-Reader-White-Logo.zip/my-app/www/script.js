const API='https://api.mangadex.org';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const ic=n=>`<svg class="i"><use href="#i-${n}"/></svg>`;
const esc=(s='')=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}};

/* ---------- networking (native on Android, fetch in a browser) ---------- */
const nativeHttp=()=>{try{return window.Capacitor?.isNativePlatform?.()?window.Capacitor.Plugins?.CapacitorHttp:null}catch(e){return null}};
const fixUrl=u=>u.replace(/\[/g,'%5B').replace(/\]/g,'%5D');
async function httpJson(url){
  const http=nativeHttp();let status,body;
  if(http){const res=await http.request({url:fixUrl(url),method:'GET',headers:{'Accept':'application/json','User-Agent':'Yomu/1.0 (Android)'}});status=res.status;body=res.data}
  else{let r;try{r=await fetch(url)}catch(e){throw Error('Network error: '+(e.message||'request blocked'))}status=r.status;body=await r.text()}
  if(typeof body==='string'){const t=body.trim();try{body=JSON.parse(t)}catch(e){throw Error(`Bad response (HTTP ${status}): ${t.slice(0,50).replace(/\s+/g,' ')}`)}}
  if(status<200||status>=300)throw Error(`Catalog error (${status})`);
  return body;
}
async function httpBlob(url){
  const http=nativeHttp();
  if(http){const res=await http.request({url:fixUrl(url),method:'GET',responseType:'blob'});if(res.status<200||res.status>=300)throw Error('Page download failed');const bin=atob(res.data),arr=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);return new Blob([arr],{type:res.headers?.['Content-Type']||res.headers?.['content-type']||'image/jpeg'})}
  const r=await fetch(url);if(!r.ok)throw Error('Page download failed');return r.blob();
}
const api=path=>httpJson(API+path);

/* ---------- state ---------- */
const state={library:load('yomu-library',[]),history:load('yomu-history',[]),theme:localStorage.getItem('yomu-theme')||'dark',sort:'relevance'};
const prefs={readerBg:'black',pageFit:'width',...load('yomu-prefs',{})};
let currentManga=null,currentChapters=[],chapterOffset=0,chapterTotal=0,currentChapterId=null,readerPages=[],objectUrls=[],lastQuery='';
const save=()=>{localStorage.setItem('yomu-library',JSON.stringify(state.library));localStorage.setItem('yomu-history',JSON.stringify(state.history))};
let toastTimer;function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2400)}

/* ---------- manga helpers ---------- */
const titleOf=m=>m.attributes?.title?.en||Object.values(m.attributes?.title||{})[0]||'Untitled';
function coverOf(m){const f=m.relationships?.find(r=>r.type==='cover_art')?.attributes?.fileName;return f?`https://uploads.mangadex.org/covers/${m.id}/${f}.256.jpg`:''}
const simple=m=>({id:m.id,title:titleOf(m),cover:coverOf(m),status:m.attributes?.status||''});
const cardHtml=x=>`<article class="card-m" data-id="${esc(x.id)}"><div class="cover">${x.cover?`<img loading="lazy" src="${esc(x.cover)}" alt="">`:`<div class="ph">${ic('book')}</div>`}${x.status?`<span class="badge">${esc(x.status)}</span>`:''}</div><h3>${esc(x.title)}</h3></article>`;
function renderGrid(el,items,empty='Nothing found.'){el.innerHTML=items.length?items.map(cardHtml).join(''):`<div class="state">${esc(empty)}</div>`;el.querySelectorAll('.card-m').forEach(c=>c.addEventListener('click',()=>openManga(c.dataset.id)))}
const LIST='includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive&hasAvailableChapters=true&availableTranslatedLanguage[]=en';
const fail=(el,e)=>{el.innerHTML=`<div class="state">${esc(e.message||'Could not load MangaDex.')}</div>`};

/* ---------- navigation ---------- */
const TITLES={home:'Home',browse:'Browse',library:'Library',downloads:'Offline',settings:'Settings'};
function navigate(page){
  $$('.page').forEach(p=>p.classList.toggle('active',p.id===`page-${page}`));
  $$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===page));
  $('#pageTitle').textContent=TITLES[page];window.scrollTo(0,0);
  if(page==='library')renderLibrary();if(page==='downloads')renderDownloads();if(page==='home')renderContinue();
}
$$('.nav').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.page)));
$$('[data-goto]').forEach(b=>b.addEventListener('click',()=>{navigate(b.dataset.goto);setTimeout(()=>$('#searchInput').focus(),50)}));

/* ---------- home ---------- */
async function popular(){const el=$('#popularGrid');try{const d=await api(`/manga?limit=12&order[followedCount]=desc&${LIST}`);renderGrid(el,d.data.map(simple))}catch(e){fail(el,e)}}
async function latest(){const el=$('#latestGrid');try{const d=await api(`/manga?limit=12&order[latestUploadedChapter]=desc&${LIST}`);renderGrid(el,d.data.map(simple))}catch(e){fail(el,e)}}
function renderContinue(){
  const items=state.history.slice(0,10).filter(x=>x.mangaId).map(x=>({id:x.mangaId,title:x.title,cover:x.cover,status:x.chapter?`Ch. ${x.chapter}`:''}));
  $('#continueSection').hidden=!items.length;
  $('#continueGrid').innerHTML=items.map(cardHtml).join('');
  $$('#continueGrid .card-m').forEach(c=>c.addEventListener('click',()=>openManga(c.dataset.id)));
}

/* ---------- search ---------- */
async function runSearch(){
  const q=$('#searchInput').value.trim();if(!q)return;lastQuery=q;
  const el=$('#browseGrid');el.innerHTML='<div class="state">Searching…</div>';
  try{const d=await api(`/manga?title=${encodeURIComponent(q)}&limit=30&order[${state.sort}]=desc&includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive`);renderGrid(el,d.data.map(simple),'No results. Try a different title.')}catch(e){fail(el,e)}
}
$('#searchForm').addEventListener('submit',e=>{e.preventDefault();$('#searchInput').blur();runSearch()});
$$('#sortChips .chip').forEach(c=>c.addEventListener('click',()=>{state.sort=c.dataset.sort;$$('#sortChips .chip').forEach(x=>x.classList.toggle('active',x===c));if($('#searchInput').value.trim())runSearch()}));

/* ---------- back-button aware overlays ---------- */
const isOpen=sel=>!$(sel).classList.contains('hidden');
function showModal(){if(!isOpen('#modal')){history.pushState({y:1},'');$('#modal').classList.remove('hidden');document.body.style.overflow='hidden'}}
function hideModal(){$('#modal').classList.add('hidden');document.body.style.overflow=''}
function showReader(){if(!isOpen('#reader')){history.pushState({y:1},'');$('#reader').classList.remove('hidden')}}
function hideReader(){$('#reader').classList.add('hidden');objectUrls.forEach(u=>URL.revokeObjectURL(u));objectUrls=[];readerPages=[];$('#readerPages').innerHTML=''}
window.addEventListener('popstate',()=>{if(isOpen('#reader'))hideReader();else if(isOpen('#modal'))hideModal()});
$('#closeModal').onclick=()=>history.back();$('#closeReader').onclick=()=>history.back();

/* ---------- manga detail ---------- */
function mergeChapters(list){
  const seen=new Set(currentChapters.map(c=>c.attributes.chapter??c.id));
  for(const ch of list){const a=ch.attributes;if(a.externalUrl||a.pages===0)continue;const key=a.chapter??ch.id;if(seen.has(key))continue;seen.add(key);currentChapters.push(ch)}
}
async function fetchChapters(id,offset){const c=await api(`/manga/${id}/feed?limit=100&offset=${offset}&translatedLanguage[]=en&order[chapter]=desc&includes[]=scanlation_group`);chapterOffset=offset+c.data.length;chapterTotal=c.total||0;mergeChapters(c.data)}
async function openManga(id){
  try{
    toast('Loading…');
    const d=await api(`/manga/${id}?includes[]=cover_art&includes[]=author&includes[]=artist`);
    currentManga=d.data;currentChapters=[];chapterOffset=0;chapterTotal=0;
    await fetchChapters(id,0);showDetail();$('#toast').classList.remove('show');
  }catch(e){toast(e.message||'Unable to load manga details')}
}
function showDetail(){
  const m=currentManga,a=m.attributes,cover=coverOf(m);
  const desc=(a.description?.en||'No description available.').split(/\n-{3,}/)[0].trim();
  const tags=[a.status,a.year,...(a.tags||[]).slice(0,4).map(t=>t.attributes.name.en)].filter(Boolean);
  const people=[...new Set(m.relationships.filter(r=>r.type==='author'||r.type==='artist').map(r=>r.attributes?.name).filter(Boolean))].join(', ');
  $('#modalContent').innerHTML=`
    <div class="detail"><div class="cover">${cover?`<img src="${esc(cover)}" alt="">`:`<div class="ph">${ic('book')}</div>`}</div>
    <div><h2>${esc(titleOf(m))}</h2>${people?`<p class="muted" style="font-size:13px">${esc(people)}</p>`:''}<div class="meta">${tags.map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div></div></div>
    <div class="actions-row"><button class="btn primary" id="readLatest">${ic('book')}Read latest</button><button class="btn" id="saveManga"></button></div>
    <p class="desc clamp" id="desc">${esc(desc)}</p>${desc.length>220?'<button class="link-btn" id="descToggle">Show more</button>':''}
    <div class="chapters-head"><h3>Chapters</h3><span class="count" id="chapCount"></span></div>
    <div class="chapter-list" id="chapterList"></div><button class="btn load-more" id="loadMore" hidden>Load more chapters</button>`;
  paintSave();renderChapters();showModal();
  $('#saveManga').onclick=()=>toggleLibrary(m);
  $('#readLatest').onclick=()=>currentChapters[0]?readChapter(currentChapters[0].id):toast('No English chapters available');
  const t=$('#descToggle');if(t)t.onclick=()=>{const d=$('#desc').classList.toggle('clamp');t.textContent=d?'Show more':'Show less'};
  $('#loadMore').onclick=async()=>{const b=$('#loadMore');b.disabled=true;b.textContent='Loading…';try{await fetchChapters(m.id,chapterOffset);renderChapters()}catch(e){toast(e.message)}b.disabled=false;b.textContent='Load more chapters'};
  $('#modal').scrollTop=0;
}
function paintSave(){const inLib=state.library.some(x=>x.id===currentManga.id),b=$('#saveManga');if(!b)return;b.innerHTML=inLib?`${ic('check')}In library`:`${ic('plus')}Add to library`}
function renderChapters(){
  $('#chapCount').textContent=currentChapters.length?`${currentChapters.length} loaded`:'';
  $('#chapterList').innerHTML=currentChapters.length?currentChapters.map(ch=>{const a=ch.attributes;return `<div class="chapter-row"><button class="read" data-ch="${ch.id}">${a.chapter?`Chapter ${esc(a.chapter)}`:'Oneshot'}${a.title?`<small>${esc(a.title)}</small>`:''}</button><button class="icon-btn" data-down="${ch.id}" aria-label="Download">${ic('download')}</button></div>`}).join(''):'<div class="state">No English chapters available.</div>';
  $$('#chapterList [data-ch]').forEach(b=>b.onclick=()=>readChapter(b.dataset.ch));
  $$('#chapterList [data-down]').forEach(b=>b.onclick=()=>downloadChapter(b.dataset.down));
  $('#loadMore').hidden=chapterOffset>=chapterTotal;
}
function toggleLibrary(m){
  const i=state.library.findIndex(x=>x.id===m.id);
  if(i>=0){state.library.splice(i,1);toast('Removed from library')}else{state.library.unshift(simple(m));toast('Added to library')}
  save();paintSave();renderLibrary();
}
function renderLibrary(){
  const q=($('#libraryFilter').value||'').toLowerCase(),items=state.library.filter(x=>x.title.toLowerCase().includes(q));
  $('#libraryCount').textContent=state.library.length?`${items.length} titles`:'';
  renderGrid($('#libraryGrid'),items,state.library.length?'No matches.':'Your library is empty. Open a manga and tap “Add to library”.');
}
$('#libraryFilter').addEventListener('input',renderLibrary);

/* ---------- reader ---------- */
async function chapterPages(id){const d=await api(`/at-home/server/${id}`);return d.chapter.data.map(f=>`${d.baseUrl}/data/${d.chapter.hash}/${f}`)}
function applyReaderPrefs(){
  $('#reader').style.background={black:'#000',dark:'#222',white:'#fff'}[prefs.readerBg]||'#000';
  $('#readerPages').className='reader-pages'+(prefs.pageFit==='height'?' fit-height':prefs.pageFit==='original'?' fit-original':'');
}
function chapterIndex(){return currentChapters.findIndex(c=>c.id===currentChapterId)}
function paintReaderNav(offline){
  const i=chapterIndex();
  $('#nextChapter').disabled=offline||i<=0;
  $('#prevChapter').disabled=offline||i<0||i>=currentChapters.length-1;
}
function paintReader(offline){
  applyReaderPrefs();
  $('#readerPages').innerHTML=readerPages.map((src,i)=>`<img src="${esc(src)}" alt="Page ${i+1}" loading="${i<3?'eager':'lazy'}">`).join('')+(offline?'':`<div class="reader-end">End of chapter<br><br><button class="btn primary" id="endNext">Next chapter</button></div>`);
  $('#readerPages').scrollTop=0;$('#reader').classList.remove('chrome-off');
  const en=$('#endNext');if(en)en.onclick=()=>goChapter(-1);
  paintReaderNav(offline);updateProgress();
}
async function readChapter(id){
  try{
    toast('Loading chapter…');
    let pages=await getOfflinePages(id);
    if(!pages.length)pages=await chapterPages(id);else objectUrls.push(...pages);
    currentChapterId=id;readerPages=pages;
    const ch=currentChapters.find(x=>x.id===id),num=ch?.attributes.chapter||'';
    $('#readerTitle').textContent=titleOf(currentManga);
    $('#readerChapter').textContent=ch?`${num?`Chapter ${num}`:'Oneshot'}${ch.attributes.title?` · ${ch.attributes.title}`:''}`:'';
    showReader();paintReader(false);$('#toast').classList.remove('show');
    const h={mangaId:currentManga.id,title:titleOf(currentManga),cover:coverOf(currentManga),chapter:num};
    state.history=[h,...state.history.filter(x=>x.mangaId!==h.mangaId)].slice(0,30);save();
  }catch(e){toast(e.message||'Could not load chapter pages')}
}
function goChapter(delta){const i=chapterIndex()+delta;if(i<0||i>=currentChapters.length){toast('No more chapters loaded');return}readChapter(currentChapters[i].id)}
$('#nextChapter').onclick=()=>goChapter(-1);$('#prevChapter').onclick=()=>goChapter(1);
let ticking=false,lastY=0;
function updateProgress(){const c=$('#readerPages'),imgs=[...c.querySelectorAll('img')];if(!imgs.length){$('#pageCount').textContent='';return}let n=1;const lim=c.getBoundingClientRect().top+c.clientHeight*.45;imgs.forEach((im,i)=>{if(im.getBoundingClientRect().top<lim)n=i+1});$('#pageCount').textContent=`${n} / ${imgs.length}`}
$('#readerPages').addEventListener('scroll',()=>{const y=$('#readerPages').scrollTop;if(y>lastY+10)$('#reader').classList.add('chrome-off');lastY=y;if(!ticking){ticking=true;requestAnimationFrame(()=>{updateProgress();ticking=false})}});
$('#readerPages').addEventListener('click',e=>{if(e.target.closest('button'))return;$('#reader').classList.toggle('chrome-off')});

/* ---------- offline downloads (IndexedDB) ---------- */
const dbPromise=new Promise((resolve,reject)=>{const req=indexedDB.open('yomu-offline',1);req.onupgradeneeded=()=>req.result.createObjectStore('chapters',{keyPath:'id'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)});
async function dbPut(v){const db=await dbPromise;return new Promise((res,rej)=>{const tx=db.transaction('chapters','readwrite');tx.objectStore('chapters').put(v);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function dbAll(){const db=await dbPromise;return new Promise((res,rej)=>{const r=db.transaction('chapters').objectStore('chapters').getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function dbDelete(id){const db=await dbPromise;return new Promise(res=>{const tx=db.transaction('chapters','readwrite');tx.objectStore('chapters').delete(id);tx.oncomplete=res})}
async function getOfflinePages(id){try{const item=(await dbAll()).find(x=>x.id===id);return item?.blobs?.map(b=>URL.createObjectURL(b))||[]}catch(e){return[]}}
async function downloadChapter(id){
  try{
    const urls=await chapterPages(id),blobs=[];
    for(let i=0;i<urls.length;i++){toast(`Downloading ${i+1} / ${urls.length}`);blobs.push(await httpBlob(urls[i]))}
    const ch=currentChapters.find(x=>x.id===id),num=ch?.attributes.chapter||'';
    await dbPut({id,mangaId:currentManga.id,manga:titleOf(currentManga),chapter:num,title:`${titleOf(currentManga)} · Chapter ${num}`,blobs});
    toast('Saved for offline reading');renderDownloads();
  }catch(e){toast('Download failed. Check storage or connection.')}
}
async function renderDownloads(){
  const el=$('#downloadsList');
  try{
    const all=await dbAll();
    el.innerHTML=all.length?all.map(x=>`<div class="row-item"><div><b>${esc(x.title)}</b><small>${x.blobs.length} pages · on this device</small></div><div class="actions"><button class="btn" data-open="${x.id}">Read</button><button class="icon-btn" data-delete="${x.id}" aria-label="Delete">${ic('trash')}</button></div></div>`).join(''):'<div class="state">No downloaded chapters yet.<br>Use the download icon next to a chapter.</div>';
    $$('[data-open]').forEach(b=>b.onclick=async()=>{const item=(await dbAll()).find(x=>x.id===b.dataset.open);if(!item)return;const urls=item.blobs.map(bl=>URL.createObjectURL(bl));objectUrls.push(...urls);readerPages=urls;currentChapterId=null;$('#readerTitle').textContent=item.manga;$('#readerChapter').textContent=`Chapter ${item.chapter} · Offline`;showReader();paintReader(true)});
    $$('[data-delete]').forEach(b=>b.onclick=async()=>{await dbDelete(b.dataset.delete);renderDownloads()});
  }catch(e){el.innerHTML='<div class="state">Offline storage is unavailable.</div>'}
}

/* ---------- settings ---------- */
function setTheme(t){state.theme=t;document.body.classList.toggle('light',t==='light');localStorage.setItem('yomu-theme',t);document.querySelector('meta[name=theme-color]').content=t==='light'?'#f6f7f9':'#0e0f13'}
$('#themeBtn').onclick=()=>setTheme(state.theme==='dark'?'light':'dark');
['readerBg','pageFit'].forEach(k=>{const el=$('#'+k);el.value=prefs[k];el.onchange=()=>{prefs[k]=el.value;localStorage.setItem('yomu-prefs',JSON.stringify(prefs));applyReaderPrefs()}});
$('#exportData').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({library:state.library,history:state.history,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'}));a.download='yomu-backup.json';a.click()};
$('#clearData').onclick=async()=>{
  if(!confirm('Delete your library, reading history and downloaded chapters?'))return;
  state.library=[];state.history=[];save();
  const db=await dbPromise,tx=db.transaction('chapters','readwrite');tx.objectStore('chapters').clear();
  tx.oncomplete=()=>{renderLibrary();renderDownloads();renderContinue();toast('All data cleared')};
};

/* ---------- start ---------- */
setTheme(state.theme);applyReaderPrefs();renderContinue();renderLibrary();popular();latest();
